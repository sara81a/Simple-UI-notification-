package com.example.assiment_notif;


import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public static final String CHANNEL_1_ID = "High";
    public static final String CHANNEL_2_ID = "low";
    PendingIntent pendingIntent;
    Intent intent;
    private Button Buttonopen;
    AlertDialog.Builder builder;
    Button btnNotif;
    EditText textinput;
    EditText titelinput;
    EditText take;
    String title;
    String text;
    String parsStrin;
    String LO="low";
    String Hi="high";
    NotificationManagerCompat managerCompat ;
    private NotificationManagerCompat notificationManager;
    private NotificationManager manager;

    @RequiresApi(api = Build.VERSION_CODES.M)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        managerCompat = NotificationManagerCompat.from(this);

       titelinput =(EditText) findViewById(R.id.editTextTextPersonName);
       textinput =(EditText) findViewById(R.id.editTextTextPersonName2);
     take=(EditText) findViewById(R.id. editTextTextPersonName3);
        btnNotif = findViewById(R.id.Notify_btn);


        notificationManager=NotificationManagerCompat.from(getApplicationContext());
        manager = (NotificationManager) getSystemService(NotificationManager.class);
        intent= new Intent(this,MainActivity2.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK| Intent.FLAG_ACTIVITY_SINGLE_TOP);



        btnNotif.setOnClickListener(new View.OnClickListener() {//click action
            @Override
            public void onClick(View view) {
                intent.putExtra("title",titelinput.getText().toString());
                intent.putExtra("text",textinput.getText().toString());
                pendingIntent= PendingIntent.getActivity(MainActivity.this,1,intent, PendingIntent.FLAG_UPDATE_CURRENT);


                parsStrin=take.getText().toString();
                if (parsStrin.equalsIgnoreCase(Hi)){
                    sendOnChannel1(null);}

                else if (parsStrin.equalsIgnoreCase(LO)) {
                    sendOnChannel2(null);}
                else{
                    Toast.makeText(getApplicationContext(),"just Enter High or Low ",
                            Toast.LENGTH_SHORT).show();

                }


            }
        });


        Buttonopen = (Button) findViewById(R.id.Reset_btn);
        builder = new AlertDialog.Builder(this);
        Buttonopen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder.setTitle("clear");
                builder.setMessage("Do you want to clear the text")
                        .setCancelable(false)

                        .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                                Toast.makeText(getApplicationContext(),"it is a cancel option ",
                                        Toast.LENGTH_SHORT).show();
                            }

                        })
                        .setPositiveButton("Reset", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                NotificationManager notificationManager = (NotificationManager)
                                        getSystemService(Context.
                                                NOTIFICATION_SERVICE);
                                notificationManager.cancelAll();
                                dialog.cancel();
                                titelinput.getText().clear();
                                textinput.getText().clear();
                             take.getText().clear();
                                Toast.makeText(getApplicationContext(),"it is  Reset option",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });

                AlertDialog alert = builder.create();
                alert.setTitle("Are you sure?");
                alert.show();
            }
        });
    }

    public void sendOnChannel1 (View v){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel1 = manager.getNotificationChannel(CHANNEL_1_ID);
            if (channel1 == null) {
                channel1 = new NotificationChannel(CHANNEL_1_ID, "My Channel 1", NotificationManager.IMPORTANCE_HIGH);
                channel1.setDescription("here is chanel 1");
                manager.createNotificationChannel(channel1);
            }

        }

        title=titelinput.getText().toString();
        text=textinput.getText().toString();

        NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this,CHANNEL_1_ID);
        builder.setContentTitle(title);
        builder.setContentText(text);
        builder.setSmallIcon(R.drawable.ic_two);

        builder.setPriority(NotificationCompat.PRIORITY_HIGH);
        builder.setCategory(NotificationCompat.CATEGORY_MESSAGE);
        builder.setContentIntent(pendingIntent);
        managerCompat.notify(1, builder.build());
    }


    public void sendOnChannel2 (View v) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel2 = manager.getNotificationChannel(CHANNEL_2_ID);
            if (channel2 == null) {
                channel2 = new NotificationChannel(CHANNEL_2_ID, "My Channel 1", NotificationManager.IMPORTANCE_LOW);
                channel2.setDescription("here is channel2");
                manager.createNotificationChannel(channel2);
            }

        }
      title = titelinput.getText().toString();
        text = textinput.getText().toString();


        NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, CHANNEL_2_ID);
        builder.setContentTitle(title);
        builder.setContentText(text);
        builder.setSmallIcon(R.drawable.ic_two);

        builder.setPriority(NotificationCompat.PRIORITY_HIGH);
        builder.setCategory(NotificationCompat.CATEGORY_MESSAGE);
        builder.setContentIntent(pendingIntent);

        managerCompat.notify(2, builder.build());

    }

}