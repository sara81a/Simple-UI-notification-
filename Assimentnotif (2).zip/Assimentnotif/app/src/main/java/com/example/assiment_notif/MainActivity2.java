package com.example.assiment_notif;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView fortitel ;
    TextView fortitel2 ;
    String titleMain ;
    String TextMain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent MyIntent = getIntent();

        onNewIntent(getIntent());
        setContentView(R.layout.activity_main2);
    fortitel =(TextView) findViewById(R.id.textView7);
       fortitel2 =(TextView) findViewById(R.id.textView8);

        titleMain = MyIntent.getStringExtra("title");
        TextMain = MyIntent.getStringExtra("text");

    fortitel.setText(titleMain);//display the titel of the notification
        fortitel2.setText(TextMain);//display the text of the notification

    }

    public void Back(View view) {//to go back to the main activity
     Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }

}